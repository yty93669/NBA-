from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import requests
import os
import time
import re

class NBATeamPlayerCrawler:
    def __init__(self):
        self.setup_driver()
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.all_players = []
        
    def setup_driver(self):
        """设置Chrome浏览器驱动"""
        chrome_options = Options()
        # chrome_options.add_argument('--headless')  # 取消无头模式，方便调试
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--window-size=1920,1080')
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
        
        try:
            self.driver = webdriver.Chrome(options=chrome_options)
            print("Chrome驱动初始化成功")
        except Exception as e:
            print(f"Chrome驱动初始化失败: {e}")
            raise
    
    def wait_for_page_load(self, timeout=10):
        """等待页面加载完成"""
        try:
            wait = WebDriverWait(self.driver, timeout)
            # 根据HTML结构，等待team-chunk元素出现
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".team-chunk")))
            return True
        except TimeoutException:
            print("页面加载超时")
            return False
    
    def get_team_elements(self):
        """获取所有球队元素"""
        team_selectors = [
            # 根据HTML结构更新选择器
            ".team-chunk",
            "[class*='team-chunk']",
            "[data-v-bade537c].team-chunk"
        ]
        
        teams = []
        for selector in team_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    print(f"选择器 '{selector}' 找到 {len(elements)} 个球队元素")
                    teams = elements
                    break  # 找到就停止尝试其他选择器
            except Exception as e:
                print(f"选择器 '{selector}' 出错: {e}")
                continue
        
        return teams
    
    def click_team(self, team_element):
        """点击球队元素"""
        try:
            # 尝试多种点击方式
            try:
                team_element.click()
                return True
            except:
                # 如果直接点击失败，尝试JavaScript点击
                self.driver.execute_script("arguments[0].click();", team_element)
                return True
        except Exception as e:
            print(f"点击球队失败: {e}")
            return False
    
    def get_team_name(self, team_element):
        """获取球队名称 - 修复版本"""
        try:
            # 方法1: 查找team-name类的span元素
            try:
                team_name_span = team_element.find_element(By.CSS_SELECTOR, ".team-name")
                team_name = team_name_span.text.strip()
                if team_name:
                    return team_name
            except:
                pass
            
            # 方法2: 查找包含one-line-ellipsis类的span元素
            try:
                team_name_span = team_element.find_element(By.CSS_SELECTOR, "span.one-line-ellipsis")
                team_name = team_name_span.text.strip()
                if team_name:
                    return team_name
            except:
                pass
            
            # 方法3: 查找所有span元素，寻找包含中文的
            try:
                spans = team_element.find_elements(By.TAG_NAME, "span")
                for span in spans:
                    text = span.text.strip()
                    if text and any('\u4e00' <= char <= '\u9fff' for char in text):
                        return text
            except:
                pass
            
            # 方法4: 从图片的alt属性获取
            try:
                img = team_element.find_element(By.TAG_NAME, "img")
                alt_text = img.get_attribute("alt")
                if alt_text and any('\u4e00' <= char <= '\u9fff' for char in alt_text):
                    return alt_text
            except:
                pass
         
            # 方法5: 尝试从data属性获取
            for attr in ['data-team', 'data-team-name', 'title']:
                try:
                    value = team_element.get_attribute(attr)
                    if value and any('\u4e00' <= char <= '\u9fff' for char in value):
                        return value
                except:
                    continue
     
            return "未知球队"
            
        except Exception as e:
            print(f"获取球队名称时出错: {e}")
            return "未知球队"
    
    def wait_for_player_table(self, timeout=10):
        """等待球员表格加载"""
        try:
            wait = WebDriverWait(self.driver, timeout)
            # 等待表格或球员列表出现
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "table, .player-list, [class*='player']")))
            time.sleep(2)  # 额外等待确保数据加载完成
            return True
        except TimeoutException:
            print("球员表格加载超时")
            return False
    
    def extract_players_from_table(self, team_name):
        """从表格中提取球员信息"""
        players = []
        
        try:
            # 查找表格行
            table_selectors = [
                "table tbody tr",
                "table tr",
                "tbody tr", 
                "[class*='table'] tr",
                ".player-row",
                "[data-player]"
            ]
            
            rows = []
            for selector in table_selectors:
                try:
                    found_rows = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if found_rows and len(found_rows) > 1:  # 确保不只是表头
                        rows = found_rows
                        print(f"使用选择器 '{selector}' 找到 {len(rows)} 行数据")
                        break
                except:
                    continue
            
            if not rows:
                print("未找到表格行")
                return players
            
            for i, row in enumerate(rows):
                try:
                    # 跳过表头行
                    if i == 0:
                        row_text = row.text.lower()
                        if any(header in row_text for header in ['姓名', '英文', '号码', '位置', 'name', 'position']):
                            continue
                    
                    # 查找行中的图片
                    img_elements = row.find_elements(By.TAG_NAME, "img")
                    if not img_elements:
                        continue
                    
                    img_url = img_elements[0].get_attribute("src")
                    if not img_url or 'player' not in img_url.lower():
                        continue
                    
                    # 查找行中的文本，获取球员姓名
                    cells = row.find_elements(By.CSS_SELECTOR, "td, th")
                    player_name = "未知球员"
                    
                    # 通常第一个或第二个单元格包含球员姓名
                    for j, cell in enumerate(cells[:3]):  # 只检查前3个单元格
                        text = cell.text.strip()
                        # 查找看起来像中文姓名的文本
                        if text and 2 <= len(text) :
                            # 检查是否包含中文字符
                            if any('\u4e00' <= char <= '\u9fff' for char in text):
                                # 排除一些明显不是姓名的文本
                                exclude_words = ['位置', '身高', '体重', '球龄', 'cm', 'kg', '前锋', '后卫', '中锋', '号码']
                                if not any(exclude in text for exclude in exclude_words):
                                    player_name = text
                                    break
                    
                    if img_url and player_name != "未知球员":
                        players.append({
                            'name': player_name,
                            'team': team_name,
                            'img_url': img_url
                        })
                        print(f"找到球员: {team_name} - {player_name}")
                    
                except Exception as e:
                    print(f"处理表格行时出错: {e}")
                    continue
            
        except Exception as e:
            print(f"提取球员信息时出错: {e}")
        
        return players
    
    def clean_filename(self, filename):
        """清理文件名"""
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        return filename.strip()
    
    def download_image(self, img_url, filename, save_dir):
        """下载图片"""
        try:
            if not img_url.startswith('http'):
                img_url = 'https:' + img_url if img_url.startswith('//') else 'https://sports.qq.com' + img_url
            
            response = self.session.get(img_url, timeout=10)
            response.raise_for_status()
            
            os.makedirs(save_dir, exist_ok=True)
            
            ext = '.jpg'
            if 'content-type' in response.headers:
                content_type = response.headers['content-type']
                if 'png' in content_type:
                    ext = '.png'
                elif 'gif' in content_type:
                    ext = '.gif'
            
            filepath = os.path.join(save_dir, filename + ext)
            
            with open(filepath, 'wb') as f:
                f.write(response.content)
            
            print(f"下载成功: {filename}")
            return True
            
        except Exception as e:
            print(f"下载图片失败 {filename}: {e}")
            return False
    
    def debug_team_structure(self):
        """调试球队结构"""
        try:
            team_elements = self.get_team_elements()
            if team_elements:
                print(f"找到 {len(team_elements)} 个球队元素")
                for i, team in enumerate(team_elements[:3]):  # 只调试前3个
                    print(f"\n=== 球队 {i+1} 结构调试 ===")
                    print(f"HTML: {team.get_attribute('outerHTML')[:200]}...")
                    print(f"文本内容: '{team.text}'")
                    
                    # 查找所有子元素
                    spans = team.find_elements(By.TAG_NAME, "span")
                    print(f"找到 {len(spans)} 个span元素:")
                    for j, span in enumerate(spans):
                        print(f"  span {j}: '{span.text}' (class: {span.get_attribute('class')})")
                    
                    imgs = team.find_elements(By.TAG_NAME, "img")
                    print(f"找到 {len(imgs)} 个img元素:")
                    for j, img in enumerate(imgs):
                        print(f"  img {j}: alt='{img.get_attribute('alt')}', src='{img.get_attribute('src')[:50]}...'")
        except Exception as e:
            print(f"调试时出错: {e}")
    
    def crawl_all_teams_players(self, url, save_dir='nba_all_players'):
        """爬取所有球队的球员"""
        try:
            print("开始爬取所有NBA球队的球员图片...")
            
            # 访问页面
            print(f"正在访问: {url}")
            self.driver.get(url)
            
            # 等待页面加载
            if not self.wait_for_page_load():
                print("页面加载失败")
                return
            
            time.sleep(3)  # 等待页面完全加载
            
            # 调试球队结构
            print("调试球队结构...")
            self.debug_team_structure()
            
            # 获取所有球队元素
            print("查找球队元素...")
            team_elements = self.get_team_elements()
            
            if not team_elements:
                print("未找到球队元素，保存页面用于调试")
                with open('debug_teams_page.html', 'w', encoding='utf-8') as f:
                    f.write(self.driver.page_source)
                return
            
            print(f"找到 {len(team_elements)} 个球队元素")
           
            # 遍历每个球队
            processed_teams = set()
            
            for i, team_element in enumerate(team_elements):
                try:
                    team_name = self.get_team_name(team_element)
                    
                    # 避免重复处理同一球队
                    if team_name in processed_teams or team_name == "未知球队":
                        if team_name == "未知球队":
                            print(f"跳过未知球队 (索引 {i})")
                        continue
                    
                    print(f"\n正在处理球队 ({i+1}/{len(team_elements)}): {team_name}")
                    
                    # 点击球队
                    if not self.click_team(team_element):
                        print(f"无法点击球队: {team_name}")
                        continue
                    
                    # 等待球员表格加载
                    if not self.wait_for_player_table():
                        print(f"球员表格加载超时: {team_name}")
                        continue
                    
                    # 提取该球队的球员信息
                    team_players = self.extract_players_from_table(team_name)
                    
                    if team_players:
                        print(f"{team_name} 找到 {len(team_players)} 个球员")
                        self.all_players.extend(team_players)
                        processed_teams.add(team_name)
                    else:
                        print(f"{team_name} 未找到球员")
                    
                    time.sleep(2)  # 等待间隔
                    
                except Exception as e:
                    print(f"处理球队时出错: {e}")
                    continue
            
            print(f"\n总共找到 {len(self.all_players)} 个球员")
            
            # 下载所有球员图片
            if self.all_players:
                print("开始下载球员图片...")
                success_count = 0
                
                for i, player in enumerate(self.all_players):
                    try:
                        filename = f"{player['team']}_{player['name']}"
                        filename = self.clean_filename(filename)
                        
                        print(f"正在下载 ({i+1}/{len(self.all_players)}): {filename}")
                        
                        if self.download_image(player['img_url'], filename, save_dir):
                            success_count += 1
                        
                        time.sleep(0.3)  # 下载间隔
                        
                    except Exception as e:
                        print(f"下载球员图片时出错: {e}")
                        continue
                
                print(f"\n爬取完成！成功下载 {success_count} 张球员图片")
            else:
                print("未找到任何球员信息")
            
        except Exception as e:
            print(f"爬取过程中出错: {e}")
        finally:
            self.driver.quit()

def main():
    crawler = NBATeamPlayerCrawler()
    url = "https://sports.qq.com/nba/players-list"
    crawler.crawl_all_teams_players(url, save_dir="nba_all_players")

if __name__ == "__main__":
    main()