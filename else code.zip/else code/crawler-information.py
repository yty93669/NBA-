from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import requests
import os
import time
import re
import csv
import pandas as pd

class NBATeamPlayerCrawler:
    def __init__(self):
        self.setup_driver()
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.all_players = []
        
    def setup_driver(self):
        """设置Chrome浏览器驱动"""
        chrome_options = Options()
        # chrome_options.add_argument('--headless')  # 取消无头模式，方便调试
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--window-size=1920,1080')
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
        
        try:
            self.driver = webdriver.Chrome(options=chrome_options)
            print("Chrome驱动初始化成功")
        except Exception as e:
            print(f"Chrome驱动初始化失败: {e}")
            raise
    
    def wait_for_page_load(self, timeout=10):
        """等待页面加载完成"""
        try:
            wait = WebDriverWait(self.driver, timeout)
            # 根据HTML结构，等待team-chunk元素出现
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".team-chunk")))
            return True
        except TimeoutException:
            print("页面加载超时")
            return False
    
    def get_team_elements(self):
        """获取所有球队元素"""
        team_selectors = [
            # 根据HTML结构更新选择器
            ".team-chunk",
            "[class*='team-chunk']",
            "[data-v-bade537c].team-chunk"
        ]
        
        teams = []
        for selector in team_selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    print(f"选择器 '{selector}' 找到 {len(elements)} 个球队元素")
                    teams = elements
                    break  # 找到就停止尝试其他选择器
            except Exception as e:
                print(f"选择器 '{selector}' 出错: {e}")
                continue
        
        return teams
    
    def click_team(self, team_element):
        """点击球队元素"""
        try:
            # 尝试多种点击方式
            try:
                team_element.click()
                return True
            except:
                # 如果直接点击失败，尝试JavaScript点击
                self.driver.execute_script("arguments[0].click();", team_element)
                return True
        except Exception as e:
            print(f"点击球队失败: {e}")
            return False
    
    def get_team_name(self, team_element):
        """获取球队名称 - 修复版本"""
        try:
            # 方法1: 查找team-name类的span元素
            try:
                team_name_span = team_element.find_element(By.CSS_SELECTOR, ".team-name")
                team_name = team_name_span.text.strip()
                if team_name:
                    return team_name
            except:
                pass
            
            # 方法2: 查找包含one-line-ellipsis类的span元素
            try:
                team_name_span = team_element.find_element(By.CSS_SELECTOR, "span.one-line-ellipsis")
                team_name = team_name_span.text.strip()
                if team_name:
                    return team_name
            except:
                pass
            
            # 方法3: 查找所有span元素，寻找包含中文的
            try:
                spans = team_element.find_elements(By.TAG_NAME, "span")
                for span in spans:
                    text = span.text.strip()
                    if text and any('\u4e00' <= char <= '\u9fff' for char in text):
                        return text
            except:
                pass
            
            # 方法4: 从图片的alt属性获取
            try:
                img = team_element.find_element(By.TAG_NAME, "img")
                alt_text = img.get_attribute("alt")
                if alt_text and any('\u4e00' <= char <= '\u9fff' for char in alt_text):
                    return alt_text
            except:
                pass
         
            # 方法5: 尝试从data属性获取
            for attr in ['data-team', 'data-team-name', 'title']:
                try:
                    value = team_element.get_attribute(attr)
                    if value and any('\u4e00' <= char <= '\u9fff' for char in value):
                        return value
                except:
                    continue
     
            return "未知球队"
            
        except Exception as e:
            print(f"获取球队名称时出错: {e}")
            return "未知球队"
    
    def wait_for_player_table(self, timeout=10):
        """等待球员表格加载"""
        try:
            wait = WebDriverWait(self.driver, timeout)
            # 等待表格或球员列表出现
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "table, .player-list, [class*='player']")))
            time.sleep(2)  # 额外等待确保数据加载完成
            return True
        except TimeoutException:
            print("球员表格加载超时")
            return False
    
    def extract_players_from_table(self, team_name):
        """从表格中提取球员信息 - 增强版本，提取完整信息"""
        players = []
        
        try:
            # 查找表格行
            table_selectors = [
                "table tbody tr",
                "table tr",
                "tbody tr", 
                "[class*='table'] tr",
                ".player-row",
                "[data-player]"
            ]
            
            rows = []
            for selector in table_selectors:
                try:
                    found_rows = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if found_rows and len(found_rows) > 1:  # 确保不只是表头
                        rows = found_rows
                        print(f"使用选择器 '{selector}' 找到 {len(rows)} 行数据")
                        break
                except:
                    continue
            
            if not rows:
                print("未找到表格行")
                return players
            
            # 首先分析表头，确定各列的位置
            header_row = rows[0]
            header_cells = header_row.find_elements(By.CSS_SELECTOR, "td, th")
            
            # 定义列索引映射
            column_mapping = {
                'name_cn': -1,    # 中文姓名
                'name_en': -1,    # 英文姓名  
                'number': -1,     # 号码
                'position': -1,   # 位置
                'height': -1,     # 身高
                'weight': -1,     # 体重
                'experience': -1  # 球龄
            }
            
            # 分析表头，确定各列位置
            for i, cell in enumerate(header_cells):
                text = cell.text.strip().lower()
                if '姓名' in text or 'name' in text:
                    column_mapping['name_cn'] = i
                elif '英文' in text or 'english' in text:
                    column_mapping['name_en'] = i
                elif '号码' in text or 'number' in text:
                    column_mapping['number'] = i
                elif '位置' in text or 'position' in text:
                    column_mapping['position'] = i
                elif '身高' in text or 'height' in text:
                    column_mapping['height'] = i
                elif '体重' in text or 'weight' in text:
                    column_mapping['weight'] = i
                elif '球龄' in text or 'experience' in text or '年' in text:
                    column_mapping['experience'] = i
            
            print(f"列映射: {column_mapping}")
            
            # 处理数据行
            for i, row in enumerate(rows):
                try:
                    # 跳过表头行
                    if i == 0:
                        continue
                    
                    # 查找行中的图片
                    img_elements = row.find_elements(By.TAG_NAME, "img")
                    if not img_elements:
                        continue
                    
                    img_url = img_elements[0].get_attribute("src")
                    if not img_url or 'player' not in img_url.lower():
                        continue
                    
                    # 获取所有单元格
                    cells = row.find_elements(By.CSS_SELECTOR, "td, th")
                    if len(cells) < 6:  # 至少应该有6列数据
                        continue
                    
                    # 初始化球员信息
                    player_info = {
                        'team': team_name,
                        'name_cn': '',
                        'name_en': '',
                        'number': '',
                        'position': '',
                        'height': '',
                        'weight': '',
                        'experience': '',
                        'img_url': img_url
                    }
                    
                    # 根据列映射提取数据，如果没有明确的列映射，使用默认位置
                    try:
                        # 如果有列映射就使用，否则使用默认位置
                        if column_mapping['name_cn'] != -1:
                            player_info['name_cn'] = cells[column_mapping['name_cn']].text.strip()
                        else:
                            # 寻找中文姓名（通常在前几列）
                            for j in range(min(3, len(cells))):
                                text = cells[j].text.strip()
                                if text and 2 <= len(text) <= 8 and any('\u4e00' <= char <= '\u9fff' for char in text):
                                    exclude_words = ['位置', '身高', '体重', '球龄', 'cm', 'kg', '前锋', '后卫', '中锋', '号码']
                                    if not any(exclude in text for exclude in exclude_words):
                                        player_info['name_cn'] = text
                                        break
                        
                        # 提取其他信息
                        if column_mapping['name_en'] != -1 and column_mapping['name_en'] < len(cells):
                            player_info['name_en'] = cells[column_mapping['name_en']].text.strip()
                        elif len(cells) > 1:
                            # 英文名通常在第二列
                            player_info['name_en'] = cells[1].text.strip()
                        
                        if column_mapping['number'] != -1 and column_mapping['number'] < len(cells):
                            player_info['number'] = cells[column_mapping['number']].text.strip()
                        elif len(cells) > 2:
                            player_info['number'] = cells[2].text.strip()
                        
                        if column_mapping['position'] != -1 and column_mapping['position'] < len(cells):
                            player_info['position'] = cells[column_mapping['position']].text.strip()
                        elif len(cells) > 3:
                            player_info['position'] = cells[3].text.strip()
                        
                        if column_mapping['height'] != -1 and column_mapping['height'] < len(cells):
                            player_info['height'] = cells[column_mapping['height']].text.strip()
                        elif len(cells) > 4:
                            player_info['height'] = cells[4].text.strip()
                        
                        if column_mapping['weight'] != -1 and column_mapping['weight'] < len(cells):
                            player_info['weight'] = cells[column_mapping['weight']].text.strip()
                        elif len(cells) > 5:
                            player_info['weight'] = cells[5].text.strip()
                        
                        if column_mapping['experience'] != -1 and column_mapping['experience'] < len(cells):
                            player_info['experience'] = cells[column_mapping['experience']].text.strip()
                        elif len(cells) > 6:
                            player_info['experience'] = cells[6].text.strip()
                        
                    except IndexError:
                        print(f"列索引超出范围，跳过该球员")
                        continue
                    
                    # 验证必要信息
                    if player_info['name_cn'] and player_info['name_cn'] != "未知球员":
                        players.append(player_info)
                        print(f"找到球员: {team_name} - {player_info['name_cn']} ({player_info['name_en']})")
                    
                except Exception as e:
                    print(f"处理表格行时出错: {e}")
                    continue
            
        except Exception as e:
            print(f"提取球员信息时出错: {e}")
        
        return players
    
    def clean_filename(self, filename):
        """清理文件名"""
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        return filename.strip()
    
    
    def save_to_csv(self, filename='nba_players_info.csv'):
        """保存球员信息到CSV文件"""
        try:
            if not self.all_players:
                print("没有球员数据可保存")
                return False
            
            # 定义CSV列
            fieldnames = ['team', 'name_cn', 'name_en', 'number', 'position', 'height', 'weight', 'experience', 'img_url']
            
            with open(filename, 'w', newline='', encoding='utf-8-sig') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                # 写入表头
                writer.writeheader()
                
                # 写入数据
                for player in self.all_players:
                    writer.writerow(player)
            
            print(f"球员信息已保存到 {filename}")
            print(f"共保存 {len(self.all_players)} 名球员的信息")
            
            # 使用pandas显示统计信息
            try:
                df = pd.DataFrame(self.all_players)
                print(f"\n数据统计:")
                print(f"球队数量: {df['team'].nunique()}")
                print(f"球员总数: {len(df)}")
                print(f"\n各队球员数量:")
                print(df['team'].value_counts())
            except Exception as e:
                print(f"显示统计信息时出错: {e}")
            
            return True
            
        except Exception as e:
            print(f"保存CSV文件时出错: {e}")
            return False
    
    def debug_team_structure(self):
        """调试球队结构"""
        try:
            team_elements = self.get_team_elements()
            if team_elements:
                print(f"找到 {len(team_elements)} 个球队元素")
                for i, team in enumerate(team_elements[:3]):  # 只调试前3个
                    print(f"\n=== 球队 {i+1} 结构调试 ===")
                    print(f"HTML: {team.get_attribute('outerHTML')[:200]}...")
                    print(f"文本内容: '{team.text}'")
                    
                    # 查找所有子元素
                    spans = team.find_elements(By.TAG_NAME, "span")
                    print(f"找到 {len(spans)} 个span元素:")
                    for j, span in enumerate(spans):
                        print(f"  span {j}: '{span.text}' (class: {span.get_attribute('class')})")
                    
                    imgs = team.find_elements(By.TAG_NAME, "img")
                    print(f"找到 {len(imgs)} 个img元素:")
                    for j, img in enumerate(imgs):
                        print(f"  img {j}: alt='{img.get_attribute('alt')}', src='{img.get_attribute('src')[:50]}...'")
        except Exception as e:
            print(f"调试时出错: {e}")
    
    def crawl_all_teams_players(self, url, save_dir='nba_all_players', download_images=True):
        """爬取所有球队的球员"""
        try:
            print("开始爬取所有NBA球队的球员信息...")
            
            # 访问页面
            print(f"正在访问: {url}")
            self.driver.get(url)
            
            # 等待页面加载
            if not self.wait_for_page_load():
                print("页面加载失败")
                return
            
            time.sleep(3)  # 等待页面完全加载
            
            # 调试球队结构
            print("调试球队结构...")
            self.debug_team_structure()
            
            # 获取所有球队元素
            print("查找球队元素...")
            team_elements = self.get_team_elements()
            
            if not team_elements:
                print("未找到球队元素，保存页面用于调试")
                with open('debug_teams_page.html', 'w', encoding='utf-8') as f:
                    f.write(self.driver.page_source)
                return
            
            print(f"找到 {len(team_elements)} 个球队元素")
           
            # 遍历每个球队
            processed_teams = set()
            
            for i, team_element in enumerate(team_elements):
                try:
                    team_name = self.get_team_name(team_element)
                    
                    # 避免重复处理同一球队
                    if team_name in processed_teams or team_name == "未知球队":
                        if team_name == "未知球队":
                            print(f"跳过未知球队 (索引 {i})")
                        continue
                    
                    print(f"\n正在处理球队 ({i+1}/{len(team_elements)}): {team_name}")
                    
                    # 点击球队
                    if not self.click_team(team_element):
                        print(f"无法点击球队: {team_name}")
                        continue
                    
                    # 等待球员表格加载
                    if not self.wait_for_player_table():
                        print(f"球员表格加载超时: {team_name}")
                        continue
                    
                    # 提取该球队的球员信息
                    team_players = self.extract_players_from_table(team_name)
                    
                    if team_players:
                        print(f"{team_name} 找到 {len(team_players)} 个球员")
                        self.all_players.extend(team_players)
                        processed_teams.add(team_name)
                    else:
                        print(f"{team_name} 未找到球员")
                    
                    time.sleep(2)  # 等待间隔
                    
                except Exception as e:
                    print(f"处理球队时出错: {e}")
                    continue
            
            print(f"\n总共找到 {len(self.all_players)} 个球员")
            
            # 保存球员信息到CSV
            print("保存球员信息到CSV...")
            self.save_to_csv()
        
            print("\n爬取完成！球员信息已保存到CSV文件")
            
        except Exception as e:
            print(f"爬取过程中出错: {e}")
        finally:
            self.driver.quit()

def main():
    crawler = NBATeamPlayerCrawler()
    url = "https://sports.qq.com/nba/players-list"
    # download_images参数控制是否下载图片，设为False只保存信息到CSV
    crawler.crawl_all_teams_players(url, save_dir="nba_all_players", download_images=True)

if __name__ == "__main__":
    main()